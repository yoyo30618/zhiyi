export const courceAreaLabelStyle = {color:'red'};

export const debugArrowStyle = {width: '20px'};

export const controlToolIconStyle = {
    width: '40px',
    height: '40px',
}